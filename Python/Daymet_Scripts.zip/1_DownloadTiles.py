
#--------------------------------------------------
#Script: 1_DownloadTiles.py
#Author: Stefanie Bohms, SGT Inc. (USGS/EROS)
#Use: Download Daymet tiles (.nc files) from http://daymet.ornl.gov/thredds server by weather parameter
#Note: need wget installed on system to be able to retrieve files (http://gnuwin32.sourceforge.net/packages/wget.htm)

#import modules
import sys, os, traceback, datetime, time, string, glob

try:

    #Output directory for data downloaded - enter path when prompted by script
    filedir = raw_input('Enter Output path (e.g. D:\daymet): ')
    #change to ouput directory
    os.chdir(filedir)
    #year for which data will be downloaded - enter year when prompted by script
    year = raw_input('Enter year to be downloaded(yyyy): ') # 2008
    # enter txt file with tile IDs, see tiles.txt for example - enter path when prompted by script
    tiletxtdir = raw_input('Enter path and tile list (e.g. D:\daymet\tiles.txt): ')
    #access txt file
    tiles = open(tiletxtdir, 'r') 
    print year
    #create a folder with the year in output folder
    yeardir = filedir + os.sep + year
    if not os.path.exists(yeardir):
        os.mkdir(yeardir)
    #enter weather parameter e.g. tmin  - enter parameter when prompted by script
    type = raw_input('Enter type: ')
    # loop through txt file and download the tiles for the tiles ID given
    for tile in tiles:
        print tile
        intile = tile[0:5]
        tiledir = yeardir + os.sep + str(intile)
        if not os.path.exists(tiledir):
            os.mkdir(tiledir)
        os.chdir(tiledir)
        netdcffile = os.system('wget http://daymet.ornl.gov/thredds/fileServer/allcf/'+ year + '/' + str(intile) +'_' + year + '/' + type + '.nc')

except:
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n    " + str(sys.exc_type)+ ": " + str(sys.exc_value) + "\n"
    print pymsg
