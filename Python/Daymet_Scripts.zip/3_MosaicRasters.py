#--------------------------------------------------
#Script: 3_MosaicRasters.py
#Author: Stefanie Bohms, SGT Inc. (USGS/EROS)
#Use: mosaic raster files to needed extent
#Note: Need ArcGIS 10.1

#Import system modules
import arcpy
from arcpy.sa import *
from arcpy import env
import sys, os, traceback, datetime, time, string, glob 
arcpy.CheckOutExtension("Spatial")

#Define Coordinate system
Coordsystem = "GEOGCS['GCS_WGS_1984',DATUM['D_WGS_1984',SPHEROID['WGS_1984',6378137.0,298.257223563]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]]"

try:
    #Output directory where raster data are - enter path when prompted by script
    filedir = raw_input('Enter Output path (e.g. D:\daymet): ')
    #year for which data will be converted - enter year when prompted by script
    year = raw_input('Enter year (yyyy): ')
    yeardir = filedir + os.sep + year
    # enter txt file with tile IDs, see tiles.txt for example - enter path when prompted by script
    tiletxtdir = raw_input('Enter path and tile list (e.g. D:\daymet\tiles.txt): ')
    #enter weather parameter e.g. tmin  - enter parameter when prompted by script
    type = raw_input('Enter type: ')
    #define ArcGIS geodatabase file 
    dataname1 = raw_input('Enter a geodatabase file name: ') # e.g. Name1
    dataname = dataname1 + '.gdb'
    #create empty geodatabase 
    arcpy.CreateFileGDB_management(filedir, dataname)
    mosaicgdb = filedir +"\\" + dataname
    #enter the start day for mosiacking, usually 0
    s = int(raw_input('Enter start day (start with 0 to mosaic day 1): ')) #start at 0 to mosaic day 1, if script stops, continue with last day mosaiced, day range is 0 - 364 days

    # loop through tif rasters until the last day is reached = 364
    while s <= 364:
        
        mosaicdataset = type + year[-2:] + ('00'+str(s+1))[-3:]
        #1.step: create an empty mosaic dataset
        arcpy.CreateMosaicDataset_management(mosaicgdb, mosaicdataset, Coordsystem, "1", "32_BIT_FLOAT", "NONE", "")
        print s
        tempList = []
        #access txt file
        tiles = open(tiletxtdir, 'r')
        #loop through tile list and take the day and add it to the mosaic dataset
        for tile in tiles:
            intile = tile[0:5]
            tiledir = yeardir + os.sep + str(intile)
            netfile = tiledir + os.sep + type
            mosaicA = netfile + os.sep + type + "_" + str(s) + ".tif"
            print mosaicA
            #2. step: add rasters to mosaic dataset
            arcpy.AddRastersToMosaicDataset_management(mosaicgdb +"\\" + mosaicdataset,"Raster Dataset",mosaicA,"UPDATE_CELL_SIZES","UPDATE_BOUNDARY","NO_OVERVIEWS","#","0","1500","#","#","SUBFOLDERS","ALLOW_DUPLICATES","BUILD_PYRAMIDS","CALCULATE_STATISTICS","NO_THUMBNAILS","#","NO_FORCE_SPATIAL_REFERENCE")

        tiles.close()
        #define name for mosaicked output raster file
        name = type + year[-2:] +('00'+str(s+1))[-3:] + '.tif'
        print name
        outdir = yeardir + os.sep + type
        if not os.path.exists(outdir):
            os.mkdir(outdir)

        #Set Mosaic Dataset Properties tool in ArcGIS 10.1 to increase file number which can be added to the mosaic dataset
        arcpy.SetMosaicDatasetProperties_management(mosaicgdb +"\\" + mosaicdataset, "", "", "", "", "", "", "BILINEAR", "", "", "", "", "Basic", "Basic", "", "", "", "", "DESCENDING", "BLEND", "10", "", "", "1000", "", "", "", "", "", "", "", "", "", "50", "1000")        
        #Copy Mosaic Dataset to a TIFF format Raster Dataset
        arcpy.CopyRaster_management(mosaicgdb+"\\"+mosaicdataset, outdir+"//"+name,"#","#","-3.402823e+038","NONE","NONE","32_BIT_FLOAT","NONE","NONE")

        print "Mosaic output raster file for day " +str(s + 1) + " created"
        s += 1
        del tiles
        del tempList
        del name
        del mosaicdataset
    print "done"

except:
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n    " + str(sys.exc_type)+ ": " + str(sys.exc_value) + "\n"
    arcpy.AddError(pymsg)
    print pymsg






    